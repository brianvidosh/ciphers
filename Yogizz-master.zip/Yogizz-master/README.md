# Yogizz
Website for Yoga Studio displaying general info about trainers,previous workshops,contact details etc.
